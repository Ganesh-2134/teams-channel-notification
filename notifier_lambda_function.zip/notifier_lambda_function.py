import boto3
import json
import os
import logging

region_name = 'eu-west-1'
client = boto3.client(
    service_name='lambda',
    region_name=region_name
)

IMAGES = {
    'SUCCEEDED': 'https://i.imgur.com/ftZpMRn.jpg',
    'STARTED': 'https://i.imgur.com/yoBT1DB.jpg'
}
IMAGE_DEFAULT = 'https://i.imgur.com/yDMuNo0.jpg'

COLOURS = {
    'SUCCEEDED': '#CEDB56',
    'STARTED': '#76CDD8'
}
COLOUR_DEFAULT = '#d34c47'

PIPELINES = {
    # 'pet-dev-': 'DEV',
    # 'pet-sit-': 'SIT',
    # 'pet-e2e-': 'E2E',
    # 'pet-uat-': 'UAT',
    # 'pet-nft-': 'NFT',
    # 'pet-oat-': 'OAT',
    'pet-digital-smoke-': 'SIT-TEST',
    'pet-digital-smoke-': 'SIT',
    # 'pet-pipelines-master': 'AWS',
    'default': 'AWS',
}

MSTeamsSendFunction = os.environ.get('MSTeamsSendFunction')

def pipeline2environment(pipeline):
    for pip in PIPELINES:
        if pipeline.startswith(pip):
            return PIPELINES[pip]
    return PIPELINES['default']

# Lambda entry point
def handler(event, context):
    logging.basicConfig(level=logging.DEBUG)
    print(f'Event: {json.dumps(event)}')
    if not 'Records' in event:
        return
        

    for record in event['Records']:
        if 'Sns' in record and 'Message' in record['Sns']:
            message = json.loads(record['Sns']['Message'])
            new_event={}
            
            if 'detail' in message and "state" in message['detail']:
                print("Test for processing pipeline")
                logging.debug("Test for processing pipeline")
                detail = message['detail']
                time = message['time']
                status = detail["state"]
                colour = COLOURS.get(status, COLOUR_DEFAULT)
                image = IMAGES.get(status, IMAGE_DEFAULT)
                region = message["region"]
                pipeline = detail["pipeline"]
                executionId = detail["execution-id"]
                title = f'[AWS CodePipeline Notification | {region}](https://{region}.console.aws.amazon.com/codesuite/codepipeline/pipelines/{pipeline}/executions/{executionId}/timeline?region={region})'
                facts = [
                    {'name': 'Status', 'value': status},
                    {'name': 'Date', 'value': time.replace('Z', 'UTC')}]
                new_msg = {
                        'channel': pipeline2environment(pipeline),
                        'colour': colour,
                        'facts': facts,
                        'image': image,
                        'subtitle': f'Pipeline {pipeline}',
                        'title': title
                    }
                new_event.update(new_msg)

                client.invoke(
                    FunctionName=MSTeamsSendFunction,
                    InvocationType='Event',
                    Payload=json.dumps(new_event)  # Convert to JSON
                )


            if 'detail' in message and "state" not in message.keys():
                print("Test for processing build")
                logging.debug("Test for processing build")
                detail = message['detail']
                if 'additional-information' in detail:
                    additional_information = detail['additional-information']
                    print("Test for processing additional-information")
                    logging.debug("Test for processing additional-information")
                    if 'logs' in additional_information:
                        print("Test for processing logs")
                        logging.debug("Test for processing logs")                      
                        logs = additional_information['logs']
                        print("Test for processing build logs")
                        logging.debug("Test for processing build logs")
                        if detail["build-status"] in  ["SUCCEEDED","FAILED"]:
                            print("Test for processing build-status")
                            logging.debug("Test for processing build-status")
                            status =  detail["build-status"]
                            account = message ["account"]
                            project_name = detail ["project-name"]
                            stream_name = logs ["stream-name"]
                            region = message["region"]
                            colour = COLOURS.get(status, COLOUR_DEFAULT)
                            image = IMAGES.get(status, IMAGE_DEFAULT)
                            time = message['time']
                            report_link = f'[AWS CodeBuild Report URL | {region}](https://{region}.console.aws.amazon.com/codesuite/codebuild/{account}/projects/{project_name}/build/{project_name}:{stream_name}/reports?region={region})'
                            print(report_link)
                            logging.debug(report_link)
                            facts = [
                                {'name': 'Status', 'value': status},
                                {'name': 'Date', 'value': time.replace('Z', 'UTC')}]                            
                            # new_data={ 'Report': report_link}
                            build_msg  = {
                                # 'channel': pipeline2environment(pipeline),
                                'channel': pipeline2environment(project_name),
                                'colour': colour,
                                'facts': facts,
                                'image': image,
                                'subtitle': f'Report-URL {project_name}',
                                'title': report_link,
                                'text': report_link,
                            }
                            # new_event.update(new_msg)

                            client.invoke(
                                FunctionName=MSTeamsSendFunction,
                                InvocationType='Event',
                                Payload=json.dumps(build_msg)  # Convert to JSON
                            )
                        if detail["build-status"]=="IN_PROGRESS":
                            pass
                
            

            # client.invoke(
            #         FunctionName=MSTeamsSendFunction,
            #         InvocationType='Event',
            #         Payload=json.dumps(new_event)  # Convert to JSON
            #     )
