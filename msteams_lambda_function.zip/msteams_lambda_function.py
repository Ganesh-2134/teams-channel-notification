import boto3
import base64
import json
import urllib3

secret_name = 'pet.msteams.webhooks'
region_name = 'eu-west-1'
msteams_host = 'directlinegroup.webhook.office.com'

client = boto3.client(
    service_name='secretsmanager',
    region_name=region_name
)

http = urllib3.PoolManager()

# Build and send message
def send_message(webhook, message=None, title=None, subtitle=None, facts=None, image=None, colour='#CEDB56'):
    payload = {
        '@type': 'MessageCard',
        '@context': 'http://schema.org/extensions',
        'themeColor': colour
    }

    if message:
        payload['text'] = message
    if title:
        payload['summary'] = title
    if title or subtitle or facts or image:
        payload['sections'] = []
        section = {'markdown': True}
        if title:
            section['activityTitle'] = title
        if subtitle:
            section['activitySubtitle'] = subtitle
        if image:
            section['activityImage'] = image
        if facts:
            section['facts'] = facts
        payload['sections'].append(section)

    r = http.request('POST', webhook, body=json.dumps(payload).encode(), headers={'Content-Type': 'application/json'})
    r.read()

# Determine webhook from secrets manager
def get_webhook(channel):
    get_secret_value_response = client.get_secret_value(SecretId=secret_name)

    if 'SecretString' in get_secret_value_response:
        secret = get_secret_value_response['SecretString']
    else:
        secret = base64.b64decode(get_secret_value_response['SecretBinary'])

    webhooks = json.loads(secret)
    if channel in webhooks:
        return f'https://{msteams_host}{webhooks[channel]}'

    return False

# Lambda entry point
def handler(event, context):
    print(f'Event: {json.dumps(event)}')

    if 'channel' not in event:
        print('Missing parameter "channel"')
        raise ValueError('Missing parameter "channel"')

    webhook = get_webhook(event['channel'])
    if not webhook:
        print(f'Invalid value "{event["channel"]}" for parameter "channel"')
        raise ValueError('Invalid value for parameter "channel"')

    send_message(
        webhook=webhook,
        colour=event.get('colour', None),
        facts=event.get('facts', None),
        image=event.get('image', None),
        message=event.get('message', None),
        subtitle=event.get('subtitle', None),
        title=event.get('title', None),
    )
